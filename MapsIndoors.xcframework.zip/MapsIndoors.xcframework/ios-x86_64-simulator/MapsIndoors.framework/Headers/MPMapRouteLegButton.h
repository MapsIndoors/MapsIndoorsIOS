//
//  MapActionButton.h
//  MapsIndoorsGenericApp
//
//  Created by Daniel Nielsen on 30/09/15.
//  Copyright © 2015 MapsPeople A/S. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPMapRouteLegButton : UIButton

@end
