// Auto-generated file - Do not modify
#define MI_SDK_VERSION        @"3.42.0-beta2"
#define MI_SDK_VERSION_MAJOR  3
#define MI_SDK_VERSION_MINOR  42
#define MI_SDK_VERSION_PATCH  0
#define MI_SDK_VERSION_LABEL  @"beta2"
