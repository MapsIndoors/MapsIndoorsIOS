// Auto-generated file - Do not modify
#define MI_SDK_VERSION        @"3.40.0"
#define MI_SDK_VERSION_MAJOR  3
#define MI_SDK_VERSION_MINOR  40
#define MI_SDK_VERSION_PATCH  0
#define MI_SDK_VERSION_LABEL  @""
