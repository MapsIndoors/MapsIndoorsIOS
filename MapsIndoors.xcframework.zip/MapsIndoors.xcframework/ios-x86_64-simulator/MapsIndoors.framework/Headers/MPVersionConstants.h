



// Auto-generated file - Do not modify
#define MI_SDK_VERSION        @"3.50.2"
#define MI_SDK_VERSION_MAJOR  3
#define MI_SDK_VERSION_MINOR  50
#define MI_SDK_VERSION_PATCH  2
#define MI_SDK_VERSION_LABEL  @""
