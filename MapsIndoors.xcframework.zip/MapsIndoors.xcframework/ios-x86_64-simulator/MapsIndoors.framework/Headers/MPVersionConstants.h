



// Auto-generated file - Do not modify
#define MI_SDK_VERSION        @"3.43.0"
#define MI_SDK_VERSION_MAJOR  3
#define MI_SDK_VERSION_MINOR  43
#define MI_SDK_VERSION_PATCH  0
#define MI_SDK_VERSION_LABEL  @""
