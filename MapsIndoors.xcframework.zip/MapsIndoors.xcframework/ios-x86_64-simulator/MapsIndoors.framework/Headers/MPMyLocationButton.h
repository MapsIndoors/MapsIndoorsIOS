//
//  MPMyLocationButton.h
//  MapsIndoors
//
//  Created by Daniel Nielsen on 05/10/15.
//  Copyright © 2015 MapsPeople A/S. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPMyLocationButton : UIButton

@end
