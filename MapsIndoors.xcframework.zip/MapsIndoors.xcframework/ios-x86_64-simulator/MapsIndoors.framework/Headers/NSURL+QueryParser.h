#import <Foundation/Foundation.h>

@interface NSURL (QueryParser)

- (nonnull NSDictionary*)queryDictionary;

@end

