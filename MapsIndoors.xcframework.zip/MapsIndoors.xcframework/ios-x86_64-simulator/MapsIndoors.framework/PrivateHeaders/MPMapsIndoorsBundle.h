//
//  MPMapsIndoorsBundle.h
//  MapsIndoors
//
//  Created by Daniel Nielsen on 12/08/2019.
//  Copyright © 2019 MapsPeople A/S. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MPMapsIndoorsBundle : NSObject

+ (NSBundle*)bundle;
+ (void)checkBundlePresence;

@end

NS_ASSUME_NONNULL_END
