//
//  MapActionButton.h
//  MapsIndoorsGenericApp
//
//  Created by Daniel Nielsen on 30/09/15.
//  Copyright © 2015 MapsPeople A/S. All rights reserved.
//

#import <UIKit/UIKit.h>

#pragma mark - [INTERNAL - DO NOT USE]

/// > Warning: [INTERNAL - DO NOT USE]
@interface MPMapRouteLegButton : UIButton

@end
