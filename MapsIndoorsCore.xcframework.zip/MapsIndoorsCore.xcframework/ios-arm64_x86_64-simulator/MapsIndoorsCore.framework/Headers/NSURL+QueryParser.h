#import <Foundation/Foundation.h>

#pragma mark - [INTERNAL - DO NOT USE]

/// > Warning: [INTERNAL - DO NOT USE]
@interface NSURL (QueryParser)

- (nonnull NSDictionary*)queryDictionary;

@end

