//
//  MPMyLocationButton.h
//  MapsIndoors
//
//  Created by Daniel Nielsen on 05/10/15.
//  Copyright © 2015 MapsPeople A/S. All rights reserved.
//

#import <UIKit/UIKit.h>

#pragma mark - [INTERNAL - DO NOT USE]

/// > Warning: [INTERNAL - DO NOT USE]
@interface MPMyLocationButton : UIButton

@end
