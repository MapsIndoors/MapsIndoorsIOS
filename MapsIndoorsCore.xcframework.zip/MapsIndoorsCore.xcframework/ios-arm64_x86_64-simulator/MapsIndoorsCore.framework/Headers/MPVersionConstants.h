



// Auto-generated file - Do not modify
#define MI_SDK_VERSION        @"4.0.0-beta4"
#define MI_SDK_VERSION_MAJOR  4
#define MI_SDK_VERSION_MINOR  0
#define MI_SDK_VERSION_PATCH  0
#define MI_SDK_VERSION_LABEL  @"beta4"
